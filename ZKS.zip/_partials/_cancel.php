 <a class="btn btn-secondary" name="cancel" type="submit" onclick="history.back(-1)">Cancel</a>

